job('cloud') {
    steps {
        shell('echo Hello World!')
    }
}